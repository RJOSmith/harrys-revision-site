export default function GCSEMockSite() {
  return <h1>Harry's Revision Site</h1>;
}
